let currentZone = 'UTC';

const timezoneFacts = {
  'UTC': 'Coordinated Universal Time (UTC) is the primary time standard by which the world regulates clocks and time. It does not observe Daylight Saving Time and remains constant year-round.',
  'America/New_York': 'Eastern Standard Time (EST) covers the eastern coast of the US and Canada. It is 5 hours behind UTC (UTC-5) during standard time and switches to Eastern Daylight Time (EDT) in the summer.',
  'Asia/Kolkata': 'Indian Standard Time (IST) is 5 hours and 30 minutes ahead of UTC (UTC+5:30). India is one of the few large countries that observes a half-hour offset time zone instead of a full hour.'
};

const themeClasses = {
  'UTC': 'theme-utc',
  'America/New_York': 'theme-est',
  'Asia/Kolkata': 'theme-ist'
};

function switchTimezone(zone, buttonElement) {
  currentZone = zone;

  document.body.className = themeClasses[zone];

  const buttons = document.querySelectorAll('.tz-btn');
  buttons.forEach(btn => btn.classList.remove('active'));
  buttonElement.classList.add('active');

  const labelMap = {
    'UTC': 'UTC Time',
    'America/New_York': 'EST (New York) Time',
    'Asia/Kolkata': 'IST (India) Time'
  };
  document.getElementById('timezone-label').textContent = labelMap[zone];

  const clockEl = document.getElementById('clock');
  clockEl.classList.remove('fade-in');
  void clockEl.offsetWidth;
  clockEl.classList.add('fade-in');

  updateClock();
}

function updateClock() {
  const now = new Date();

  const formattedTime = now.toLocaleTimeString('en-US', {
    timeZone: currentZone,
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });

  document.getElementById('clock').textContent = formattedTime;
}

function updateCountdown() {
  const now = new Date();
  const currentYear = now.getFullYear();
  const targetDate = new Date(`January 1, ${currentYear + 1} 00:00:00`);

  const diff = targetDate - now;

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = String(Math.floor((diff / (1000 * 60 * 60)) % 24)).padStart(2, '0');
  const minutes = String(Math.floor((diff / (1000 * 60)) % 60)).padStart(2, '0');
  const seconds = String(Math.floor((diff / 1000) % 60)).padStart(2, '0');

  document.getElementById('countdown').textContent = `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

function openModal() {
  const labelMap = {
    'UTC': 'UTC Fact',
    'America/New_York': 'EST (New York) Fact',
    'Asia/Kolkata': 'IST (India) Fact'
  };
  document.getElementById('modal-title').textContent = labelMap[currentZone];
  document.getElementById('modal-body').textContent = timezoneFacts[currentZone];
  document.getElementById('fact-modal').classList.add('active');
}

function closeModal() {
  document.getElementById('fact-modal').classList.remove('active');
}

updateClock();
updateCountdown();

setInterval(() => {
  updateClock();
  updateCountdown();
}, 1000);
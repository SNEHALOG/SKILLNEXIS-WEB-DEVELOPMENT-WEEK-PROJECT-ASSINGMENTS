const readline = require("readline").createInterface({
  input: process.stdin,
  output: process.stdout
});

readline.question("Enter a number: ", (input) => {
  const num = Number(input.trim());

  if (!Number.isInteger(num)) {
    console.log("Please enter a valid integer.");
  } else if (num % 2 === 0) {
    console.log(`${num} is Even`);
  } else {
    console.log(`${num} is Odd`);
  }

  readline.close();
});